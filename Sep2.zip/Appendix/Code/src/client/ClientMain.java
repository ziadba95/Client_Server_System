package client;

import java.awt.EventQueue;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;

import controller.CreateEventsController;
import controller.LoginController;
import controller.NewsFeedController;
import controller.SignUpController;
import controller.StatusCtrlr;
import view.AddInterestGUI;
import view.CreateEventView;
import view.LoginView;
import view.MainGUI;
import view.NewsFeedPanel;
import view.SearchView;
import view.SignUpView;
import view.StatusView;

public class ClientMain {
	public static void main(String[] args) {
		System.setProperty("java.security.policy", "file:./all.policy");

		   if (System.getSecurityManager() == null)
		   {
		      System.setSecurityManager(new RMISecurityManager());
		   }   

		Client client = new Client();
		LoginView view = new LoginView();
		LoginController loginCtrlr = new LoginController(client,view);
		

	}

}
