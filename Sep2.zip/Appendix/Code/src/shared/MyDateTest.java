package shared;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class MyDateTest {
MyDate after;
MyDate before;
MyDate equalsAfter;

@Before
public void setUp() {
	after=new MyDate(10, 0,10,19,12,2018);
	equalsAfter=new MyDate(10, 0,10,19,12,2018);
	
	
	before=new MyDate(10, 0,10,17,12,2018);
	
}

	@Test
	public void testIsBefore1() {
		boolean temp;
		temp=before.isBefore(after);
		assertTrue(temp);
	}
	@Test
	public void testIsBeforeEqualDates() {
		boolean temp;
		temp=after.isBefore(equalsAfter);
		assertFalse(temp);
	}
	@Test
	public void testYear() {
		before.setYear(2016);
		after.setYear(2019);
		boolean temp;
		temp=before.isBefore(after);
		assertTrue(temp);
	}
	@Test
	public void testMonth() {
		before.setMonth(10);
		after.setMonth(11);
		boolean temp;
		temp=before.isBefore(after);
		assertTrue(temp);
	}
	
	@Test
	public void testDay() {
		before.setDay(10);
		after.setDay(11);
		boolean temp;
		temp=before.isBefore(after);
		assertTrue(temp);
	}
	@Test
	public void testHour() {
		before.setHour(10);
		after.setHour(11);
		boolean temp;
		temp=before.isBefore(after);
		assertTrue(temp);
	}
	@Test
	public void testMinute() {
		before.setMinute(10);
		after.setMinute(11);
		boolean temp;
		temp=before.isBefore(after);
		assertTrue(temp);
	}
	@Test
	public void testSecond() {
		before.setSecond(10);
		after.setSecond(11);
		boolean temp;
		temp=before.isBefore(after);
		assertTrue(temp);
	}
}
