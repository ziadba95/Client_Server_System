package view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

import com.sun.org.apache.xalan.internal.xsltc.compiler.sym;

import controller.EditController;

public class EditView extends JPanel {

	private EditController ctrlr;

	public JPasswordField getConfirm() {
		return confirm_1;
	}

	public void setConfirm(JPasswordField confirm) {
		this.confirm_1 = confirm;
	}

	public JPasswordField getPass() {
		return pass;
	}

	private JPasswordField pass;
	private JButton btnLogIn;
	private JLabel lblPassword_1;
	private JLabel lblConfirmPassword;
	private JPasswordField confirm;
	private JPasswordField confirm_1;

	/**
	 * Create the application.
	 */
	public EditView() {
		setBackground(new Color(51, 102, 153));
		initialize();
		setBounds(100, 100, 445, 303);
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap(27, Short.MAX_VALUE)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
								.addComponent(lblPassword_1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(lblConfirmPassword, GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE))
							.addGap(18)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(pass, GroupLayout.PREFERRED_SIZE, 154, GroupLayout.PREFERRED_SIZE)
								.addComponent(confirm_1, GroupLayout.PREFERRED_SIZE, 154, GroupLayout.PREFERRED_SIZE))
							.addGap(111))
						.addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
							.addComponent(btnLogIn)
							.addGap(137))))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(56)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblPassword_1, GroupLayout.PREFERRED_SIZE, 36, GroupLayout.PREFERRED_SIZE)
						.addComponent(pass, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(58)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(confirm_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(34)
							.addComponent(btnLogIn))
						.addComponent(lblConfirmPassword, GroupLayout.PREFERRED_SIZE, 36, GroupLayout.PREFERRED_SIZE))
					.addGap(60))
		);
		setLayout(groupLayout);
	}

	public void setController(EditController ctrlr) {
		this.ctrlr = ctrlr;
	}

	public void showMessage(String body) {
		JOptionPane.showMessageDialog(null, body);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		btnLogIn = new JButton("UPDATE");
		btnLogIn.setBackground(new Color(0, 153, 153));
		btnLogIn.setForeground(Color.DARK_GRAY);
		btnLogIn.setFont(new Font("Verdana", Font.PLAIN, 17));
		btnLogIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("hi");

				String password = String.valueOf(pass.getPassword());
				System.out.println(password);
				String confirm1 = String.valueOf(confirm.getPassword());
				System.out.println(confirm1);
				if (password.length() == 0 || confirm1.length() == 0) {
					showMessage("info is missing");
				} else {
					if (password.equals(confirm1)) {
						try {
							if (ctrlr.userInfoIsCorrectEdit(password, confirm1)) {
								showMessage("your information updated ");
							} else {
								showMessage("info is wrong");
							}

						} catch (SQLException e1) {
							e1.printStackTrace();
						}
					} else {
						showMessage("passwords not matching");
					}

				}
			}
		});

		pass = new JPasswordField();
		pass.setFont(new Font("Verdana", Font.PLAIN, 17));

		lblPassword_1 = new JLabel("Password:");
		lblPassword_1.setForeground(new Color(0, 0, 0));
		lblPassword_1.setFont(new Font("Verdana", Font.BOLD, 17));

		confirm = new JPasswordField();
		lblConfirmPassword = new JLabel("Confirm:");
		lblConfirmPassword.setForeground(new Color(0, 0, 0));
		lblConfirmPassword.setFont(new Font("Verdana", Font.BOLD, 17));

		confirm_1 = new JPasswordField();
		confirm_1.setFont(new Font("Verdana", Font.PLAIN, 17));
	}
}