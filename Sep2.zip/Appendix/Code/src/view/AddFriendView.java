package view;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.TrayIcon.MessageType;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import controller.AddFriendController;
import shared.Interest;
import shared.User;
import shared.User;
import shared.UserInfo;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.border.MatteBorder;

public class AddFriendView extends JPanel {

	private JScrollPane allUsersScrollPane;
	private JScrollPane allFriendsScrollPane;

	private JList<User> list;
	private JList<User> listOfFriends;
	private DefaultListModel<User> listModel;
	private DefaultListModel<User> listOfFriendsModel;

	private JButton viewSelectedUserBtn;
	private JButton addFriendBtn;
	private JButton searchBtn;
	private JButton refreshBtn;

	private JTextField searchTxtField;

	private MyActionListener listener;
	private JPanel panel;
	private AddFriendController ctrlr;

	private SelectionListener listListener;

	public AddFriendView() {
		setForeground(Color.BLACK);
		setBackground(new Color(51, 102, 153));

		listener = new MyActionListener();
		listModel = new DefaultListModel<>();
		listOfFriendsModel = new DefaultListModel<>();

		refreshBtn = new JButton("Refresh");
		refreshBtn.setBackground(new Color(0, 153, 153));
		refreshBtn.setForeground(Color.BLACK);
		refreshBtn.setFont(new Font("Verdana", Font.PLAIN, 17));
		refreshBtn.addActionListener(listener);
		viewSelectedUserBtn = new JButton("Info");
		viewSelectedUserBtn.setBackground(new Color(0, 153, 204));
		viewSelectedUserBtn.setForeground(Color.BLACK);
		viewSelectedUserBtn.setFont(new Font("Verdana", Font.PLAIN, 17));
		viewSelectedUserBtn.addActionListener(listener);
		addFriendBtn = new JButton("Follow");
		addFriendBtn.setBackground(new Color(0, 153, 153));
		addFriendBtn.setForeground(Color.BLACK);
		addFriendBtn.setFont(new Font("Verdana", Font.PLAIN, 17));
		addFriendBtn.addActionListener(listener);
		searchBtn = new JButton("Search");
		searchBtn.setBackground(new Color(0, 153, 204));
		searchBtn.setForeground(Color.BLACK);
		searchBtn.setFont(new Font("Verdana", Font.PLAIN, 17));
		searchBtn.addActionListener(listener);
		searchTxtField = new JTextField(10);
		searchTxtField.setBackground(Color.WHITE);
		searchTxtField.setForeground(Color.BLACK);
		searchTxtField.setHorizontalAlignment(SwingConstants.TRAILING);
		allUsersScrollPane = new JScrollPane();
		allUsersScrollPane.setPreferredSize(new Dimension(300, 300));
		allUsersScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		allFriendsScrollPane = new JScrollPane();
		allFriendsScrollPane.setPreferredSize(new Dimension(150, 150));
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(10)
							.addComponent(searchTxtField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(searchBtn)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(refreshBtn))
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING, false)
								.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
									.addComponent(viewSelectedUserBtn)
									.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addComponent(addFriendBtn))
								.addComponent(allUsersScrollPane, Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 178, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.RELATED, 73, Short.MAX_VALUE)
							.addComponent(allFriendsScrollPane, GroupLayout.PREFERRED_SIZE, 166, GroupLayout.PREFERRED_SIZE)))
					.addGap(364))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(16)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(searchTxtField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(searchBtn)
						.addComponent(refreshBtn))
					.addGap(74)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addComponent(allFriendsScrollPane, GroupLayout.DEFAULT_SIZE, 230, Short.MAX_VALUE)
						.addComponent(allUsersScrollPane, 0, 0, Short.MAX_VALUE))
					.addGap(46)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(viewSelectedUserBtn)
						.addComponent(addFriendBtn))
					.addContainerGap())
		);
		
				listOfFriends = new JList<>(listOfFriendsModel);
				listOfFriends.setBackground(Color.WHITE);
				listOfFriends.setFont(new Font("Verdana", Font.PLAIN, 17));
				listOfFriends.setForeground(Color.BLACK);
				listOfFriends.setBorder(new MatteBorder(2, 2, 1, 1, (Color) new Color(0, 102, 153)));
				allFriendsScrollPane.setViewportView(listOfFriends);
				listOfFriends.addListSelectionListener(listListener);
				listOfFriends.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
				
				JLabel lblMyFriends = new JLabel("My friends");
				lblMyFriends.setBackground(Color.DARK_GRAY);
				lblMyFriends.setForeground(Color.BLACK);
				allFriendsScrollPane.setColumnHeaderView(lblMyFriends);
				lblMyFriends.setFont(new Font("Verdana", Font.PLAIN, 17));
		
				list = new JList<>(listModel);
				list.setBackground(Color.WHITE);
				list.setFont(new Font("Verdana", Font.PLAIN, 17));
				list.setForeground(Color.BLACK);
				list.setBorder(new MatteBorder(2, 2, 1, 1, (Color) new Color(0, 102, 153)));
				allUsersScrollPane.setViewportView(list);
				list.addListSelectionListener(listListener);
				list.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
				
				JLabel lblListOfAll = new JLabel("List of all users");
				lblListOfAll.setToolTipText("");
				lblListOfAll.setBackground(Color.DARK_GRAY);
				lblListOfAll.setForeground(Color.BLACK);
				allUsersScrollPane.setColumnHeaderView(lblListOfAll);
				lblListOfAll.setFont(new Font("Verdana", Font.PLAIN, 17));
		setLayout(groupLayout);

	}

	public void setUsers(ArrayList<User> users2) {
		for (int i = 0; i < users2.size(); i++) {
			listModel.addElement(users2.get(i));

		}
	}

	public void setListOfFriends(ArrayList<User> friends) {
		for (int i = 0; i < friends.size(); i++) {
			listOfFriendsModel.addElement(friends.get(i));
			System.out.println(friends.get(i));
		}

	}

	public void setController(AddFriendController ctrlr) {
		this.ctrlr = ctrlr;
	}

	class SelectionListener implements ListSelectionListener {

		@Override
		public void valueChanged(ListSelectionEvent e) {
			if (e.getSource() == list) {
				if (list.getSelectedValue() instanceof User) {

					User temp = (User) list.getSelectedValue();

				}
			}
		}

	}

	public void showSelectedUserInfo(UserInfo userInfo, ArrayList<Interest> interests) {

		String name = " ";
		for (int i = 0; i < listModel.getSize(); i++) {
			if (listModel.getElementAt(i).getUserInformation().equals(userInfo)) {
				name = listModel.getElementAt(i).getUserName();
			}
		}
		String interestString = "";
		if (interests.size() > 0) {
			interestString = interests.get(0).toString();
			for (int i = 1; i < interests.size(); i++) {
				interestString += "-" + interests.get(i);
			}
		}
		JOptionPane.showMessageDialog(null, userInfo.getAbout() + "\n"+name+"'s interests includes:" + interestString, "About "+name,
				JOptionPane.CLOSED_OPTION);
	}

	public void search() {
		String username = searchTxtField.getText();
		boolean invalidUser = true;

		int index = 0;
		for (int i = 0; i < listModel.getSize(); i++) {

			if (listModel.getElementAt(i).getUserName().startsWith(username)) {
				invalidUser = false;
				index = i;
				break;
			}

		}
		if (!invalidUser) {
			list.setSelectedValue(listModel.get(index), true);

		} else {
			JOptionPane.showMessageDialog(null, "No match was found", null, JOptionPane.WARNING_MESSAGE);
		}
	}

	public void follow() {
		List<User> users = list.getSelectedValuesList();
		String s = "";
		User[] friends = new User[users.size()];
		for (int i = 0; i < users.size(); i++) {
			friends[i] = users.get(i);
			if (users.size() > 1) {
				s +=   users.get(i).getUserName()+", ";

			} else {
				s += users.get(i).getUserName();

			}
		}
		int choice = JOptionPane.showConfirmDialog(null, "Would you like to follow " + s + "?");
		if (choice == JOptionPane.YES_OPTION) {
			try {
				ctrlr.saveFriendsToDatabase(friends);
				ctrlr.refresh();
				JOptionPane.showMessageDialog(null, "You are now following " + s, null, JOptionPane.CLOSED_OPTION);
			} catch (RemoteException | SQLException e) {
				if (e.getMessage().contains("already exists")) {
					JOptionPane.showMessageDialog(null, "You're already following this person", "",
							JOptionPane.CLOSED_OPTION);}
				else {e.printStackTrace();}
			}
		}
	}

	public void clearLists() {
		listOfFriendsModel.clear();
		listModel.clear();
	}

	class MyActionListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == viewSelectedUserBtn) {
				if (list.getSelectedIndices().length > 1) {
					JOptionPane.showMessageDialog(null, "You can only select one person", "Error",
							JOptionPane.ERROR_MESSAGE);
				} else if (list.getSelectedIndices().length == 1)
					showSelectedUserInfo(list.getSelectedValue().getUserInformation(),
							list.getSelectedValue().getUserInterest());

			}
			if (e.getSource() == addFriendBtn) {

				follow();
			}
			if (e.getSource() == searchBtn) {
				search();

			}
			if (e.getSource() == refreshBtn) {

				ctrlr.refresh();
			}
		}
	}
}
