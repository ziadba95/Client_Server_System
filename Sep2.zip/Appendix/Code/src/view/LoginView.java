package view;
import javax.swing.JFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.Font;
import controller.LoginController;

public class LoginView {

	private JFrame frmNewInTown;
	private JTextField user;
	private LoginController ctrlr;
	private JPasswordField pass;
	private JLabel lblUsername;
	private JButton btnLogIn;
	private JLabel lblPassword_1;
	private JButton btnSignUp;
	private JLabel lblOr;
	//private LoginGuiButtonListerners btnListener;

	/**
	 * Create the application.
	 */
	public LoginView() {
		initialize();
		frmNewInTown.setVisible(true);
	}
	
	public void setController(LoginController ctrlr) {
		this.ctrlr = ctrlr;
	}
	
	public JFrame getFrame() {
		return frmNewInTown;
	}
	
	public void showMessage(String body) {
		JOptionPane.showMessageDialog(null, body);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmNewInTown = new JFrame();
		frmNewInTown.getContentPane().setFont(new Font("Verdana", Font.BOLD, 17));
		frmNewInTown.getContentPane().setBackground(new Color(51, 102, 153));
		frmNewInTown.setTitle("New in Town");
		frmNewInTown.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\crona\\Desktop\\sep2Logo.png"));
		frmNewInTown.setBounds(100, 100, 480, 341);
		frmNewInTown.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		user = new JTextField();
		user.setFont(new Font("Verdana", Font.PLAIN, 16));
		user.setColumns(10);
		
		lblUsername = new JLabel("Username:");
		lblUsername.setForeground(Color.DARK_GRAY);
		lblUsername.setFont(new Font("Verdana", Font.BOLD, 17));
		
		btnLogIn = new JButton("LOG IN");
		btnLogIn.setForeground(Color.DARK_GRAY);
		btnLogIn.setBackground(new Color(0, 153, 153));
		btnLogIn.setFont(new Font("Verdana", Font.BOLD, 17));
		btnLogIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("hi");
				String username = user.getText();
				String password = String.valueOf(pass.getPassword());
				if(!(username.length() == 0 || password.length() == 0)) {
					try {
						if(ctrlr.userInfoIsCorrect(username, password)) {
							ctrlr.goToMainView();
						}  else {
							showMessage("Wrong info");
						}
						
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				} else {
					showMessage("info is missing");
				}
			}
		});
//				String sql="select * from new_in_town.login where username=? and pass=?";
//				//db.query(sql, username, password);
//				try{
////				connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/", "postgres", "1994");
//				connection.setSchema("New in Town");
//				prestat=connection.prepareStatement(sql);
//				prestat.setString(1, user.getText());
//				String password = null;
//				password = String.valueOf(pass.getPassword());
//				prestat.setString(2,password);
//				result=prestat.executeQuery();
//				if(result.next())
//				{
//				JOptionPane.showMessageDialog(null,"YOU LOGGED IN");
//				 
//				}
//				else
//				{
//				JOptionPane.showMessageDialog(null, "username OR password is not correct");
//				}
//				}
//				catch(SQLException ex)
//				{
//				JOptionPane.showMessageDialog(null,ex);
//				}
				
		
		pass = new JPasswordField();
		pass.setFont(new Font("Verdana", Font.PLAIN, 17));
		
		lblPassword_1 = new JLabel("Password:");
		lblPassword_1.setForeground(Color.DARK_GRAY);
		lblPassword_1.setFont(new Font("Verdana", Font.BOLD, 17));
		
		btnSignUp = new JButton("SIGN UP");
		btnSignUp.setForeground(Color.DARK_GRAY);
		btnSignUp.setFont(new Font("Verdana", Font.BOLD, 17));
		btnSignUp.setBackground(new Color(0, 153, 204));
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("bye");
				frmNewInTown.setVisible(false);
				ctrlr.goToSignUp();
			}
		});
		
		lblOr = new JLabel("OR");
		lblOr.setForeground(Color.DARK_GRAY);
		lblOr.setFont(new Font("Verdana", Font.BOLD, 17));
		GroupLayout groupLayout = new GroupLayout(frmNewInTown.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(207)
							.addComponent(btnLogIn))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(28)
							.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
								.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
									.addComponent(lblUsername, GroupLayout.PREFERRED_SIZE, 124, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED))
								.addComponent(lblPassword_1, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE))
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addGroup(groupLayout.createSequentialGroup()
									.addGap(30)
									.addComponent(user, GroupLayout.PREFERRED_SIZE, 154, GroupLayout.PREFERRED_SIZE))
								.addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
									.addGap(30)
									.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
										.addComponent(btnSignUp, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
										.addComponent(pass, GroupLayout.PREFERRED_SIZE, 154, GroupLayout.PREFERRED_SIZE))))))
					.addGap(122))
				.addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
					.addContainerGap(243, Short.MAX_VALUE)
					.addComponent(lblOr)
					.addGap(188))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(53)
							.addComponent(user, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(51)
							.addComponent(lblUsername, GroupLayout.PREFERRED_SIZE, 36, GroupLayout.PREFERRED_SIZE)))
					.addGap(11)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(pass, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblPassword_1, GroupLayout.PREFERRED_SIZE, 36, GroupLayout.PREFERRED_SIZE))
					.addGap(24)
					.addComponent(btnLogIn, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(lblOr)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnSignUp, GroupLayout.PREFERRED_SIZE, 36, Short.MAX_VALUE)
					.addContainerGap())
		);
		frmNewInTown.getContentPane().setLayout(groupLayout);
	}
	
//	private class LoginGuiButtonListerners implements ActionListener{
//
//		@Override
//		public void actionPerformed(ActionEvent e) {
//			if(e.getSource() == btnLogIn) {
//				System.out.println("hi");
//				String username = user.getText();
//				String password = String.valueOf(pass.getPassword());
//				if(!(username.length() == 0 || password.length() == 0)) {
//					try {
//						ctrlr.userInfoIsCorrect(username, password);
//						
//					} catch (SQLException e1) {
//						e1.printStackTrace();
//					}
//				} else {
//					showMessage("info is missing");
//				}
//			} 
//			if(e.getSource() == btnSignUp) {
//				System.out.println("bye");
//
//				ctrlr.goToSignUp();
//			}
//		}
//		
//	}
	
}

