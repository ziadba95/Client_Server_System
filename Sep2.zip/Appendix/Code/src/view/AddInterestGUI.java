package view;

import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.DefaultListModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.LayoutStyle.ComponentPlacement;

import controller.InterestsController;
import shared.Interest;
import shared.InterestList;
import shared.User;

import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JFormattedTextField;
import java.awt.event.ActionListener;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.TitledBorder;
import javax.swing.border.MatteBorder;

public class AddInterestGUI extends JPanel{

	private JTextField textField;
	private JScrollPane scrollPane;
	private JButton btnAdd;
	private JButton btnSave;
	private JList<Interest> list;
	private DefaultListModel<Interest> listModel;
	private InterestsController ctrlr;
	private InterestButtonListener btnListener;

	
	private DefaultListModel<Interest> userInterestListModel;
	private JScrollPane allUInterestsScrollPane;
	//private JList<Interest> user_list;
	private JLabel lblMyInterests;
	private JList list_1;
	private JList<Interest> user_list;


	/**
	 * Create the application.
	 */
	public AddInterestGUI() {
		setBackground(new Color(51, 102, 153));
		initialize();
	}

	public void setController(InterestsController ctrlr) {
		this.ctrlr = ctrlr;
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		setBounds(100, 100, 596, 410);

		scrollPane = new JScrollPane();
		listModel = new DefaultListModel<Interest>();
		btnListener = new InterestButtonListener();
		
		allUInterestsScrollPane=new JScrollPane();
		userInterestListModel=new DefaultListModel<Interest>();
		


		textField = new JTextField();
		textField.setFont(new Font("Verdana", Font.PLAIN, 17));
		textField.setForeground(Color.BLACK);
		textField.setColumns(10);

		/////////////////////
		btnAdd = new JButton("Add");
		btnAdd.setBackground(new Color(0, 153, 204));
		btnAdd.setForeground(Color.BLACK);
		btnAdd.setFont(new Font("Verdana", Font.PLAIN, 17));
		btnAdd.addActionListener(btnListener);

		
		
//		allUInterestsScrollPane.setPreferredSize(new Dimension(200, 200));
//		allUInterestsScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		//////////////////////////
		btnSave = new JButton("Save");
		btnSave.setBackground(new Color(0, 153, 153));
		btnSave.setForeground(Color.BLACK);
		btnSave.setFont(new Font("Verdana", Font.PLAIN, 17));
		btnSave.addActionListener(btnListener);
		
		JLabel lblCantFindAnything = new JLabel("Add interest");
		lblCantFindAnything.setForeground(Color.BLACK);
		lblCantFindAnything.setHorizontalAlignment(SwingConstants.TRAILING);
		lblCantFindAnything.setFont(new Font("Verdana", Font.PLAIN, 17));
		
	
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 163, GroupLayout.PREFERRED_SIZE)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(18)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
								.addComponent(textField, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE)
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(btnAdd)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(btnSave, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(50)
							.addComponent(lblCantFindAnything)))
					.addGap(26)
					.addComponent(allUInterestsScrollPane, GroupLayout.PREFERRED_SIZE, 161, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(113)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(allUInterestsScrollPane, GroupLayout.PREFERRED_SIZE, 261, GroupLayout.PREFERRED_SIZE)
						.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
							.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 252, GroupLayout.PREFERRED_SIZE)
							.addGroup(groupLayout.createSequentialGroup()
								.addGap(52)
								.addComponent(lblCantFindAnything)
								.addPreferredGap(ComponentPlacement.RELATED)
								.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED)
								.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
									.addComponent(btnAdd)
									.addComponent(btnSave)))))
					.addContainerGap(153, Short.MAX_VALUE))
		);
		list = new JList<Interest>();
		list.setFont(new Font("Verdana", Font.PLAIN, 17));
		list.setForeground(Color.BLACK);
		scrollPane.setViewportView(list);
		list.setBorder(new MatteBorder(2, 2, 1, 1, (Color) Color.DARK_GRAY));
		list.setModel(listModel);
		
		JLabel lblInterestsAddBy = new JLabel("All interests");
		lblInterestsAddBy.setBackground(Color.DARK_GRAY);
		scrollPane.setColumnHeaderView(lblInterestsAddBy);
		lblInterestsAddBy.setForeground(Color.BLACK);
		lblInterestsAddBy.setFont(new Font("Verdana", Font.PLAIN, 17));
		lblInterestsAddBy.setHorizontalAlignment(SwingConstants.TRAILING);
		

		allUInterestsScrollPane.setViewportView(list_1);
		user_list = new JList<Interest>();
		user_list.setFont(new Font("Verdana", Font.PLAIN, 17));
		user_list.setForeground(Color.BLACK);
		user_list.setBorder(new MatteBorder(2, 2, 1, 1, (Color) Color.DARK_GRAY));
		allUInterestsScrollPane.setViewportView(user_list);
		user_list.setModel(userInterestListModel);
		
		lblMyInterests = new JLabel("My interests");
		lblMyInterests.setBackground(Color.DARK_GRAY);
		allUInterestsScrollPane.setColumnHeaderView(lblMyInterests);
		lblMyInterests.setFont(new Font("Verdana", Font.PLAIN, 17));
		lblMyInterests.setForeground(Color.BLACK);
		
		setLayout(groupLayout);
		
	
	}

	public void setAllInterests(InterestList interests) {
		Interest[] array = interests.getArrayOfInterests();
		listModel.removeAllElements();
		for (int i = 0; i < array.length; i++) {
			listModel.addElement(array[i]);
			
		}

	}
	public void setUsersInterests(InterestList interests) {
		Interest[] array = interests.getArrayOfInterests();
		userInterestListModel.removeAllElements();
		for (int i = 0; i < array.length; i++) {
			userInterestListModel.addElement(array[i]);
			System.out.println("users interest"+ interests.get(i));
		}

	}
	public void showMessage(String s) {
		JOptionPane.showMessageDialog(null, s);
	}

	private class InterestButtonListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == btnAdd) {
				if(textField.getText().trim().isEmpty() ) {
					showMessage("field is empty");
				}
				else{ctrlr.saveInterest(new Interest(textField.getText()));}
				
			}
			if (e.getSource() == btnSave) {
				try {
					ctrlr.addChosenInterestsIntoUserInterestTable(
							new InterestList((ArrayList<Interest>) list.getSelectedValuesList()));
				} catch (RemoteException | SQLException e1) {
					if(e1.getMessage().contains("already exists")) {
						JOptionPane.showMessageDialog(null, "You have already added this to your list of interests", "",JOptionPane.CLOSED_OPTION);

					}else {
					e1.printStackTrace();}
				}

			}

		}

	}
}