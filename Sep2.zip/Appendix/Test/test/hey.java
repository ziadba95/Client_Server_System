package test;

public class hey {
	public static void main(String[] args) {
		System.out.println("hey");
	}
}
