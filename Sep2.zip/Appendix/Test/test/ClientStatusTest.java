package test;

import client.Client;
import client.IClient;

public class ClientStatusTest {
	public static void main(String[] args) {
		Client client = new Client();
		client.setClient("naya_all");
		client.addStatus("HI");
		
	}
}
